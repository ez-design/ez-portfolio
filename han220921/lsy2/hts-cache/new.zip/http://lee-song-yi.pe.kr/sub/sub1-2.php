<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/sub1-common.css">
  <link rel="stylesheet" href="/css/sub1-1-index.css">
  <link rel="stylesheet" href="/css/sub1-2-index.css">
  <link rel="stylesheet" href="/css/sub1-3-index.css">
  <link rel="stylesheet" href="/css/sub1-4-index.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<!-- 상단 시작 { -->

<div id="skip_to_container"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <p>All Menu</p>
        <ul class="allmenu-box">
          <li class="allmenu-depth1">
            <a href="/sub/sub1-1.php"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <script>
    var allBtn = $('.allmenu');
        allBtn.each(function(index){
        var $this = $(this);
          $this.on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
          });
        });
    var depth1 = $('.allmenu-depth1');
        depth1.each(function(index){
    var $this = $(this);
        $('.allmenu-depth1 > a').on('click', function(e){
          e.preventDefault();
          $('.allmenu-depth1').removeClass('on');
          $(this).parent().toggleClass('on');
        });
    });
  </script>
</header>
<!-- } 상단 끝 -->
<!-- 콘텐츠 시작 { -->
<main id="main">
  <h2 class="hidden">메인 콘텐츠</h2>
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">브랜드 소개</p>
    </div>
  </section>
  <nav class="lnb">
    <div class="inner">
      <ul class="lnb-menu">
        <li class="lnb-menu1-current"><a href="/sub/sub1-1.php">팔공티소개</a></li>
        <li class="lnb-menu2-current"><a href="/sub/sub1-2.php">연혁</a></li>
        <li class="lnb-menu3-current"><a href="/sub/sub1-3.php">오시는길</a></li>
        <li class="lnb-menu4-current"><a href="/sub/sub1-4.php">해외사업</a></li>
      </ul>
    </div>
  </nav>
  <section class="palgong-intro intro-history global">  <link rel="stylesheet" href="/css/sub1-2-index.css">
  
  <nav class="hidden">메인 콘텐츠</nav>
  <div class="inner">
    <h3 class="history-tit"><strong>H</strong>ISTORY</h3>
    <P class="history-desc-top history-desc"><em>맛있는 차</em>를 대접하기 위해</P>
    <P class="history-desc-bottom history-desc">팔공티가 걸어온 길</P>
    <div class="history-wrap">
      <article class="history-2022">
        <strong class="left-years">2022</strong>
        <ul class="history-2022-box right-box">
          <li class="history-2022-January">
            <span>January</span>
            <p class="history-2022-January-first">팔공티 호주 1호 멜버른점 OPEN</p>
            <p class="history-2022-January-second">팔공티 LAB 매장 OPEN - 용산 아이파크몰점(Forest)</p>
          </li>
        </ul>
      </article>
      <article class="history-2021">
        <strong class="right-years">2021</strong>
        <ul class="history-2021-box left-box">
          <li class="history-2021-January">
            <span>January</span>
            <p class="history-2021-January-first">전 메뉴 개편작업</p>
            <p class="history-2021-January-second">기업부설연구소 설립</p>
          </li>
          <li class="history-2021-April">
            <span>April</span>
            <p class="history-2021-April-first">미국 시카고 1호점 오픈</p>
          </li>
          <li class="history-2021-May">
            <span>May</span>
            <p class="history-2021-May-first">팔도 비락식혜 콜라보 메뉴 출시</p>
          </li>
          <li class="history-2021-June">
            <span>June</span>
            <p class="history-2021-June-first">팔공티 가맹점 350호점 돌파</p>
          </li>
          <li class="history-2021-October">
            <span>October</span>
            <p class="history-2021-October-first">캐나다 13개점 오픈</p>
            <p class="history-2021-October-second">음료관련 원자재 전문공장 설립</p>
          </li>
        </ul>
      </article>
      <article class="history-2020">
        <strong class="left-years">2020</strong>
        <ul class="history-2020-box right-box">
          <li class="history-2020-January">
            <span>January</span>
            <p class="history-2020-January-first">212호점 팔공티 신탄진점 오픈</p>
          </li>
          <li class="history-2020-February">
            <span>February</span>
            <p class="history-2020-February-first">227호점 팔공티 천안백석점 오픈</p>
          </li>
          <li class="history-2020-April">
            <span>April</span>
            <p class="history-2020-April-first">대한민국 소비자만족대상 수상</p>
          </li>
          <li class="history-2020-June">
            <span>June</span>
            <p class="history-2020-June-first">팔공티 가맹점 300호점 돌파</p>
          </li>
          <li class="history-2020-July">
            <span>July</span>
            <p class="history-2020-July-first">미국 조인트 벤처 "PALGONG TEA" USA 출범</p>
            <p class="history-2020-July-second">미국 투자 법인 M2G investment</p>
          </li>
        </ul>
      </article>
      <article>
        <strong class="right-years">2019</strong>
        <ul class="history-2019-box left-box">
          <li class="history-2019-January">
            <span>January</span>
            <p class="history-2019-January-first">46호점 팔공티 강남역점 오픈</p>
            <p class="history-2019-January-second">BEXCO 부산창업박람회 참여</p>
          </li>
          <li class="history-2019-June">
            <span>June</span>
            <p class="history-2019-June-first">해외 1호점 팔공티 캐나다 스틸점 오픈</p>
            <p class="history-2019-January-second">해외 2호점 팔공티 캐나다 디스틸러리점 오픈</p>
          </li>
          <li class="history-2019-November">
            <span>November</span>
            <p class="history-2019-November-first">130호점 인천 대학교 내 팔공티 오픈</p>
          </li>
        </ul>
      </article>
      <article>
        <strong class="left-years">2018</strong>
        <ul class="history-2018-box right-box">
          <li class="history-2018-January">
            <span>January</span>
            <p class="history-2018-January-first">14호점 팔공티 2001 아울렛 철산점 오픈</p>
          </li>
          <li class="history-2018-March">
            <span>March</span>
            <p class="history-2018-March-first">16호점 팔공티 롯데백화점 대구점 오픈</p>
            <p class="history-2018-March-second">15호점 팔공티 롯데백화점 동래점 오픈</p>
          </li>
          <li class="history-2018-April">
            <span>April</span>
            <p class="history-2018-April-first">BEXCO 부산창업박람회 참여</p>
          </li>
          <li class="history-2018-November">
            <span>November</span>
            <p class="history-2018-November-first">45호점 팔공티 인천 청라점 오픈</p>
          </li>
        </ul>
      </article>
      <article>
        <strong class="right-years">2017</strong>
        <ul class="history-2017-box left-box">
          <li class="history-2017-May">
            <span>May</span>
            <p class="history-2017-May-first">1호점 팔공티 종로구청점 오픈</p>
          </li>
          <li class="history-2017-June">
            <span>June</span>
            <p class="history-2017-June-first">2호점 팔공티 이화여대점 오픈</p>
          </li>
          <li class="history-2017-July">
            <span>July</span>
            <p class="history-2017-July-first">4호점 팔공티 선릉점 오픈</p>
          </li>
          <li class="history-2017-November">
            <span>November</span>
            <p class="history-2017-November-first">13호점 팔공티 부산 부경대점 오픈</p>
          </li>
        </ul>
      </article>
    </div>
  </div>
<!-- } 콘텐츠 끝 -->
<!-- 하단 시작 { -->
  </section>
</main>
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
