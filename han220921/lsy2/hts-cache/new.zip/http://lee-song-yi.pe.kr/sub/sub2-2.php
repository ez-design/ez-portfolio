<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>그누보드5</title>
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/css/default.css?ver=220620">
<link rel="stylesheet" href="http://lee-song-yi.pe.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://lee-song-yi.pe.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://lee-song-yi.pe.kr";
var g5_bbs_url   = "http://lee-song-yi.pe.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="keywords" content="밀크티, 버블티, 커피, 디저트, 차, 홍차"/> 
  <meta name="description" content="자연의 찻집 팔공티입니다."/>

  <meta property="og:title" content="팔공티-PALGONGTEA"/>
  <meta property="og:type" content="website"/>
  <meta property="og:description" content="PALGONGTEA 밀크티가 맛있는 카페입니다.">
  <meta property="og:image" content="img/og.png">
<script src="http://lee-song-yi.pe.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/common.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/wrest.js?ver=221017"></script>
<script src="http://lee-song-yi.pe.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>

  <link rel="stylesheet" href="/css/sub2-common.css">
  <link rel="stylesheet" href="/css/sub2-1-index.css">
  <link rel="stylesheet" href="/css/sub2-2-index.css">

  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />  

  <script src="https://kit.fontawesome.com/979b8c848e.js" crossorigin="anonymous"></script>
  <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>


<!-- 상단 시작 { -->

<div id="skip_to_container"><a href="#container">본문 바로가기</a></div>
<header id="header">
  <div class="inner">
    <h1 class="logo"><a href="/index.php">logo</a></h1>
    <ul class="gnb">
      <li class="depth1"><a href="/sub/sub1-1.php">브랜드소개</a>
        <ul class="depth2">
          <li><a href="/sub/sub1-1.php">팔공티소개</a></li>
          <li><a href="/sub/sub1-2.php">연혁</a></li>
          <li><a href="/sub/sub1-3.php">오시는길</a></li>
          <li><a href="/sub/sub1-4.php">해외사업</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">메뉴</a>
        <ul class="depth2">
          <li><a href="/sub/sub2-1.php">주문TIP</a></li>
          <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub3-1.php">창업문의</a>
        <ul class="depth2">
          <li><a href="/sub/sub3-1.php">가맹절차</a></li>
          <li><a href="/sub/sub3-2.php">인테리어</a></li>
          <li><a href="/sub/sub3-3.php">가맹비용</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">매장안내</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내매장</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외매장</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="/sub/sub5-1.php">멤버십</a>
        <ul class="depth2">
          <li><a href="/sub/sub6-1.php">팔공티APP</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">팔공티소식</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
        </ul>
      </li>
      <li class="depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">고객문의</a>
        <ul class="depth2">
          <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드제휴</a></li>
        </ul>
      </li>
    </ul>
    <div class="tnb">
      <ul class="login-box">        
                <li class="join"><a href="http://lee-song-yi.pe.kr/bbs/register.php">회원가입</a></li>
        <li class="login"><a href="http://lee-song-yi.pe.kr/bbs/login.php">로그인</a></li>
              </ul>
      <nav class="allmenu">
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
        <span>allmenu</span>
      </nav>
      <div class="allmenu-wrap">
        <p>All Menu</p>
        <ul class="allmenu-box">
          <li class="allmenu-depth1">
            <a href="#"><p>브랜드 소개</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub1-1.php">팔공티 소개</a></li>
              <li><a href="/sub/sub1-2.php">연혁</a></li>
              <li><a href="/sub/sub1-3.php">오시는 길</a></li>
              <li><a href="/sub/sub1-4.php">해외 사업</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="#"><p>메뉴</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub2-1.php">주문 TIP</a></li>
              <li><a href="/sub/sub2-2.php">티 컬렉션</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴/신메뉴</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub3-1.php"><p>창업 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub3-1.php">가맹 절차</a></li>
              <li><a href="/sub/sub3-2.php">인테리어</a></li>
              <li><a href="/sub/sub3-3.php">가맹 비용</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=basic_qa">상담 신청</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map"><p>매장 안내</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=map">국내 매장</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=global">해외 매장</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="/sub/sub5-1.php"><p>멤버쉽</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="/sub/sub6-1.php">팔공티 APP</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice"><p>팔공티 소식</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=notice">공지사항</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=event">이벤트</a></li>
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=news">뉴스</a></li>
            </ul>
          </li>
          <li class="allmenu-depth1"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand"><p>고객 문의</p><i class="fa-solid fa-angle-up"></i></a>
            <ul class="allmenu-depth2">
              <li><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=brand">브랜드 제휴</a></li>
            </ul>
          </li>
        </ul>
      </div>
    </div>
  </div>
  <script>
    var allBtn = $('.allmenu');
        allBtn.each(function(index){
        var $this = $(this);
          $this.on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
          });
        });
    var depth1 = $('.allmenu-depth1');
        depth1.each(function(index){
    var $this = $(this);
        $('.allmenu-depth1 > a').on('click', function(e){
          e.preventDefault();
          $('.allmenu-depth1').removeClass('on');
          $(this).parent().toggleClass('on');
        });
    });
  </script>
</header>
<!-- } 상단 끝 -->
<!-- 콘텐츠 시작 { -->
<main id="main">
  <h2 class="hidden">메인 콘텐츠</h2>
  <section class="visual">
    <div class="inner">
      <p class="visual-txt">메뉴</p>
    </div>
  </section>
  <nav class="lnb">
    <div class="inner">
      <ul class="lnb-menu">
        <li class="lnb-menu1-current"><a href="/sub/sub2-1.php">주문 TIP</a></li>
        <li class="lnb-menu2-current"><a href="/sub/sub2-2.php">티 컬렉션</a></li>
        <li class="lnb-menu3-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=Season">시즌메뉴</a></li>
        <li class="lnb-menu4-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=gallery">음료</a></li>
        <li class="lnb-menu4-current"><a href="http://lee-song-yi.pe.kr/bbs/board.php?bo_table=dessert">디저트</a></li>
      </ul>
    </div>
  </nav>
  <section class="palgongtea-menu inner">  <nav class="hidden">메인 콘텐츠</nav>
  <h3 class="collec-tit"><strong>PALGONGTEA</strong> Collection</h3>
  <p class="collec-desc">팔공티의 Tea Collection입니다.</p>
  <article class="collec-right-wrap">
    <div class="collec-inner">
      <strong class="collec-right-tit">블랙티(홍차)</strong>
      <article class="collec-right-imgbox imgbox">
        <figure class="collec-right-img"><img src="/img/gall_blacktea.png" alt="#"></figure>
      </article>
      <article class="collec-right-textbox textbox">
        <p class="collec-right-txt">찻잎이 숙성되면서 붉은색을 띠고, 과일 향이 자욱해짐<br>차 탕과 엽저의 색이 “홍색”을 띠어 홍차라 부르고,<br>홍차 잎의 색은 진한 홍색 중 검은빛을 띠어 영어로는 “Black Tea”라 한다.</p>
        <dl class="collec-right-smallbox">
          <dt>숙성도</dt>
          <dd>상</dd>
        </dl>
        <div class="collec-right-temper temper">온도 <span>97℃</span></div>
        <div class="collec-right-body body1">
          <p>바디감(Body)</p>
          <p>신맛(Acidity)</p>
          <p>단맛(Sweetness)</p>
        </div>
      </article>
    </div>
    <div class="collec-inner">
      <strong class="collec-left-tit">자스민 그린티</strong>
      <article class="collec-left-imgbox imgbox">
        <figure class="collec-left-img"><img src="/img/gall_jasminetea.png" alt="#"></figure>
      </article>
      <article class="collec-left-textbox textbox">
        <p class="collec-left-txt">투명한 푸른빛 찻물 색<br>싱그럽고 우아한 향기가 오래 지속되며 맛이 매우 깔끔<br>폴리페놀과 비타민 C의 함량이 높음
        <dl class="collec-left-smallbox">
          <dt>숙성도</dt>
          <dd>하</dd>
        </dl>
        <div class="collec-left-temper temper">온도 <span>77℃</span></div>
        <div class="collec-left-body body2">
          <p>바디감(Body)</p>
          <p>신맛(Acidity)</p>
          <p>단맛(Sweetness)</p>
        </div>
      </article>
    </div>
    <div class="collec-inner">
      <strong class="collec-right-tit">얼그레이티</strong>
      <article class="collec-right-imgbox imgbox">
        <figure class="collec-right-img"><img src="/img/gall_blacktea.png" alt="#"></figure>
      </article>
      <article class="collec-right-textbox textbox">
        <p class="collec-right-txt">달콤한 꿀 향, 과일의 새콤함과 꽃의 우아한 향<br>진한 오렌지색 찻물<br>상큼한 베르가못 향이 첨가되어 있음</p>
        <dl class="collec-right-smallbox">
          <dt>숙성도</dt>
          <dd>상</dd>
        </dl>
        <div class="collec-right-temper temper">온도 <span>97℃</span></div>
        <div class="collec-right-body body3">
          <p>바디감(Body)</p>
          <p>신맛(Acidity)</p>
          <p>단맛(Sweetness)</p>
        </div>
      </article>
    </div>
    <div class="collec-inner">
      <strong class="collec-left-tit">우롱티</strong>
      <article class="collec-left-imgbox imgbox">
        <figure class="collec-left-img"><img src="/img/gall_blacktea.png" alt="#"></figure>
      </article>
      <article class="collec-left-textbox textbox">
        <p class="collec-left-txt">가공 후 찻잎의 색이 청갈색이어서 청차라 불림<br>부드러운 꽃향기와 달콤한 과일 향이 두드러짐<br>녹차와 홍차의 오묘한 조화를 느껴볼 수 있는 아주 매력적인 차</p>
        <dl class="collec-left-smallbox">
          <dt>숙성도</dt>
          <dd>상</dd>
        </dl>
        <div class="collec-left-temper temper">온도 <span>85℃</span></div>
        <div class="collec-left-body body4">
          <p>바디감(Body)</p>
          <p>신맛(Acidity)</p>
          <p>단맛(Sweetness)</p>
        </div>
      </article>
    </div>
  </article>
<!-- } 콘텐츠 끝 -->
<!-- 하단 시작 { -->
  </section>
</main>
<footer id="footer">
  <div class="inner">
    <h4 class="f-logo"><a href="#">logo</a></h4>
    <ul class="f-menu">
      <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
      <li><a href="/sub/sub-f-terms.php">이용약관</a></li>
      <li><a href="/sub/sub-f-collection.php">이메일무단수집거부</a></li>
      <li><a href="/sub/sub1-3.php">오시는길</a></li>
    </ul>
    <div class="f-hours">
      <ul class="f-open">OPENING HOURS
        <li>MON-FRI</li>
        <li>09:00 AM ~ 06:00 PM</li>
        <li>주말, 공휴일 휴무</li>
      </ul>
      <ul class="f-sns">
        <li><a href="https://ko-kr.facebook.com/Palgongtea.official/">페이스북</a></li>
        <li><a href="https://www.instagram.com/palgongtea.official/">인스타그램</a></li>
        <li><a href="https://blog.naver.com/palgongtea_official">네이버블로그</a></li>
      </ul>
    </div>
    <div class="f-adrr">
      <ul class="f-number">
        <li>사업자번호 669-88-01126</li>
        <li>㈜팔공티 대표이사 김종현</li>
      </ul>
      <ul class="f-txt">
        <li><adrress>주소 : 서울 강남구 밤고개로1길 10, 현대벤처빌 1822호 팔공티</adrress></li>
        <li>연락처 : 02-6928-8286</li>
        <li>이메일 : palgongtea@palgongtea.com</li>
      </ul>
      <p class="f-copy">ⓒ 2021 PALGONG TEA All rights reserved.</p>
    </div>
  </div>
</footer>
<!-- } 하단 끝 -->
<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
