<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>프랭크버거</title>
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=220620">
<link rel="stylesheet" href="http://khy2.dothome.co.kr/css/default.css?ver=220620">
<!--[if lte IE 8]>
<script src="http://khy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://khy2.dothome.co.kr";
var g5_bbs_url   = "http://khy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>
<script src="http://khy2.dothome.co.kr/js/jquery-1.12.4.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/jquery.menu.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/common.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/wrest.js?ver=221017"></script>
<script src="http://khy2.dothome.co.kr/js/placeholders.min.js?ver=221017"></script>
</head>
<body>
<meta name="keywords" content="수제버거, 수제버거창업, 프랭크버거, 햄버거, 햄버거창업, 버거창업, 수제햄버거, 버거">
<meta name="description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:title" content="대한민국 수제버거 No.1 프랭크 버거">
<meta property="og:type" content="website">
<meta property="og:description" content="3,900원 수제버거 창업 1등 브랜드, 100% 순소고기 정통 미국식 수제버거 프랭크버거">
<meta property="og:image" content="/img/bi.jpg">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon.png">
<link rel="stylesheet" href="/css/font.css">
<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub1.css">

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="/js/jquery.vide.js"></script>
<script src="https://kit.fontawesome.com/50dc02b2ac.js" crossorigin="anonymous"></script>

<div class="skip-nav">
    <a href="#main">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner">
        <h1 class="logo"><a href="/">프랭크버거</a></h1>
        <nav class="gnb">
            <h2 class="hidden">메인메뉴</h2>
            <ul>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거</dt>
                        <dd class="gnb-start-desc">정통 미국식<br><span>프랭크</span> 치즈버거</dd>
                    </dl>
                    <a href="/sub/sub1-1.php">브랜드소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub1-1.php">프랭크 버거</a></li>
                        <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                        <li><a href="/sub/sub1-3.php">경영철학</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 메뉴</dt>
                        <dd class="gnb-start-desc">프랭크버거 만의<br><span>특화</span>된 메뉴</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">메뉴소개</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery">Single</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery2">Side</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=gallery3">Set</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 매장</dt>
                        <dd class="gnb-start-desc"><span>가까운</span> 매장을<br>찾아보세요</dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">매장찾기</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=branches_on">가까운 매장찾기</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=newstore">신규매장</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=partner">오픈예정</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=excellent">우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 소식</dt>
                        <dd class="gnb-start-desc">빠르게 만나는<br>프랭크 <span>최신 소식</span></dd>
                    </dl>
                    <a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">뉴스</a>
                    <ul class="depth2">
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=notice">새소식</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=event">이벤트</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube">홍보광고</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=instagram">SNS</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=youtube2">성공스토리</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 회사</dt>
                        <dd class="gnb-start-desc">명품 브랜드<br>프랭크 <span>F&B</span></dd>
                    </dl>
                    <a href="/sub/sub5-1.php">회사소개</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub5-1.php">프랭크 F&B</a></li>
                        <li><a href="/sub/sub5-2.php">본사 시스템</a></li>
                        <li><a href="/sub/sub5-3.php">연혁</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <dl class="gnb-start">
                        <dt class="gnb-start-tit hidden">프랭크버거 창업</dt>
                        <dd class="gnb-start-desc">체계적인 프랜차이즈<br>프랭크버거 <span>창업하기</span></dd>
                    </dl>
                    <a href="/sub/sub6-1.php">창업안내</a>
                    <ul class="depth2">
                        <li><a href="/sub/sub6-1.php">창업 성공전략</a></li>
                        <li><a href="/sub/sub6-2.php">창업 아카데미</a></li>
                        <li><a href="/sub/sub6-3.php">창업조건 및 비용</a></li>
                        <li><a href="/sub/sub6-4.php">창업자금 지원</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/board.php?bo_table=qa">가맹FAQ</a></li>
                        <li><a href="http://khy2.dothome.co.kr/bbs/qawrite.php">가맹상담</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <p class="gnb-bg"></p>
        <nav class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://khy2.dothome.co.kr/bbs/register.php">회원가입</a></li>
                <li>
                    <a href="http://khy2.dothome.co.kr/bbs/login.php">로그인<figure><img src="/img/tnb-icon.png" alt=""></figure></a></li>
                            </ul>
        </nav>
    </div>
</header>

<main id="brand">
    <h2 class="hidden">브랜드소개</h2>
    <section class="visual">
        <div class="inner">
            <strong>브랜드소개</strong>
            <em>정통 미국식 프리미엄 치즈버거</em>
        </div>
    </section>
    <nav class="lnb">
        <div class="inner">
            <ul class="lnb-list">
                <li><a href="/sub/sub1-1.php">프랭크버거</a></li>
                <li><a href="/sub/sub1-2.php">특별함의 이유</a></li>
                <li><a href="/sub/sub1-3.php">경영철학</a></li>
            </ul>
        </div>
    </nav>
    <section class="sec inner">
<script>
    $(function(){
        $('.lnb-list li').removeClass('on')
        $('.lnb-list li').eq(1).addClass('on')
    })
</script>

<header class="sub-header">
    <h3 class="sub-tit"><span>특별함</span>의 이유</h3>
    <p class="sub-desc">프랭크버거 브랜드 런칭 3년 만에 550호점의 브랜드 파워 No.1</p>
</header>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>01</span><em>(주)FRANK F&B 자체개발</em> 검증된 브랜드</strong>
        <p class="special-list-desc">더 튼튼하고 검증된 프랜차이즈 그룹 ㈜FRANK F&B에서<br>운영하는 패밀리 브랜드이므로 안심하고 창업하세요.</p>
        <p class="special-list-desc">프랭크버거만의 차별화된 메뉴와 최상의 맛과 매장의 편리성 및 인건비 절감을 위한 가맹본사의 자체 육가공공장에서 자동생산되는 100% 순소고기 수제 패티를 사용합니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special1.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>02</span>성공 창업의 첫째 조건은 <em>정확한 트랜드 분석</em></strong>
        <p class="special-list-desc">무조건 싸게 파는 저가형 브랜드는 단명하기 쉬운 아이템이므로 절대 조심해야 합니다. 나와<br>내 가족이 안심하고 먹지 못하는 아이템은 소비자에게 절대로 인정받을 수 없습니다.</p>
        <p class="special-list-desc">프랭크버거는 현 트랜드의 흐름을 정확하게 캐치하여 대중적인 것을 특화시킨 차별화된<br>성공창업 아이템입니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special2.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>03</span><em>검증된 프랜차이즈</em> 가맹 본사 (주)FRANK F&B</strong>
        <p class="special-list-desc">아무리 좋은 아이템도 가맹본사의 운영 능력이나 프랜차이즈 인프라가 구축되지 않은 부실한<br>가맹본사는 브랜드 성공의 한계가 드러날 수 밖에 없습니다.</p>
        <p class="special-list-desc">프랭크버거 가맹 본사는 좋은 재료, 좋은 음식으로 런칭 3년 만에 550호점을 오픈 시킨 검증된<br>브랜드 가맹본사입니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special3.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>04</span>주머니가 가벼운 불경기에 맞는 <em>저렴한 메뉴구성</em></strong>
        <p class="special-list-desc">프랭크버거는 학생 직장인, 다수의 서민층의 눈높이에 맞추어 가격은 더 저렴하면서 중독성있는 맛과 비주얼로 고객만족도를 우선하였습니다.</p>
        <p class="special-list-desc">프랭크버거는 현 트랜드의 흐름을 정확하게 캐치하여 대중적인 것을 특화시킨 차별화된<br>성공창업 아이템입니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special4.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>05</span>철저한 본사 인력파견 도입으로 <em>인건비 절감</em></strong>
        <p class="special-list-desc">프랭크버거는 각 가맹점의 효율적 인력운영 시스템으로 매장 인력운영 효율을 우선하여 가맹점<br>의 안정적 운영을 극대화 시켰습니다.</p>
        <p class="special-list-desc">아무리 좋은 아이템도 가맹본사의 운영 능력이나 프랜차이즈 인프라가 구축되지 않은 부실한<br>가맹본사는 브랜드 성공의 한계가 드러날 수 밖에 없습니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special5.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>06</span>가맹 본사의 <em>홍보 광고 지원과 최고의 시스템</em></strong>
        <p class="special-list-desc">프랭크버거 가맹 본사는 100호점부터 막대한 자본을 투자하여 TV CF를 제작, 가맹점 홍보<br>광고를 지원해왔습니다.</p>
        <p class="special-list-desc">그리고 본사 운영 시스템, 전국 주요 지역 본사 직영 사업본부, 1일 10만명의 소비자 구매력,<br>약 5만명의 고용창출을 이끌어가는 우수 중견기업입니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special6.png" alt=""></figure>
</article>
<article class="special-list clearfix">
    <div class="special-list-text">
        <strong class="special-list-tit"><span>07</span>가맹점 우선의 <em>합리적인 가맹본사</em></strong>
        <p class="special-list-desc">전국 책임제 관리 시스템을 정착하여 가맹점과 소통하고 상생하는 선진  프랜차이즈 시스템으로<br>이미 각 언론과 정부, 그리고 업계에 새로운 프랜차이즈의 표본으로 인정받고 있습니다.</p>
        <p class="special-list-desc">돈을 벌기 위한 브랜드이기보다 소바자에게 더 좋은 문화와 건강, 그리고 더 안심할 수 있는<br>먹거리를 제공하는 것이 ‘프랭크 버거의 가치와 목표’입니다.</p>
    </div>
    <figure class="special-list-img"><img src="/img/sub/special7.png" alt=""></figure>
</article>

</section>
</main>

<footer id="footer">
    <button type="button" id="top_btn">
        <i class="fa fa-arrow-up" aria-hidden="true"></i><span class="sound_only">상단으로</span>
    </button>
    <div class="inner">
        <h2 class="f-logo">(주)프랭크 에프앤비</h2>
        <ul class="f-menu">
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=provision">이용약관</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=privacy">개인정보처리방침</a></li>
            <li><a href="http://khy2.dothome.co.kr/bbs/content.php?co_id=email">이메일무단수집거부</a></li>
        </ul>
        <div class="f-center">
            <em>고객지원 및 상담센터</em>
            <strong>1544 - 7733</strong>
            <p>평일 09:00 ~ 18:00 / 점심 12:00 ~ 13:00<br>(토요일 / 일요일 / 공휴일 휴무)</p>
        </div>
        <div class="f-link">
            <div class="f-link-sns">
                <a href="https://www.instagram.com/frankburger_official_/">인스타그램</a>
                <a href="https://www.youtube.com/channel/UCo3DjdEjQrr8uD_-YUt8mnA">유튜브</a>
                <a href="https://blog.naver.com/bpr2012">네이버 블로그</a>
            </div>
            <div class="f-link-family">
                <a href="http://co-tabe.co.kr/">코앤타베</a>
                <a href="http://bapuri.co.kr/new2/">밥푸리</a>
            </div>
        </div>
        <ul class="f-info">
            <li class="f-info-addr"><address>(주)프랭크 에프앤비 사업자번호 : 130-86-76090 경기도 부천시 옥산로 181</address></li>
            <li class="f-info-copy">COPYRIGHT ⓒ 2019 FRANK F&B. All Rights Reserved.</li>
        </ul>
    </div>
</footer>

    <script>
        $(function() {
            $("#top_btn").on("click", function() {
                $("html, body").animate({scrollTop:0}, '500');
                return false;
            });
        });
    </script>
    <!-- Swiper JS -->
    <script src="https://cdn.jsdelivr.net/npm/swiper/swiper-bundle.min.js"></script>
    <!-- Initialize Swiper -->
    <script>
        var swiper = new Swiper(".mySwiper", {
        slidesPerView: 1,
        spaceBetween: 0,
        loop: true,
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
        });
    </script>



<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>





</body>
</html>
