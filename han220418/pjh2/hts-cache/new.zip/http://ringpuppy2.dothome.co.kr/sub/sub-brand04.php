<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-brand.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=press&page=1">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <div class="visual">
        <div class="inner">BRAND</div>
    </div>
    <div class="lnb inner">
        <ul class="lnb-wrap">
            <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
            <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
            <li><a href="/sub/sub-brand03.php">CF</a></li>
            <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
        </ul>
    </div>
    <section class="sub01">
         <div class="inner">
<script>
    $(function(){
        $(".lnb li").removeClass();
        $(".lnb li").eq(3).addClass('on')
    })
</script>

<h2 class="tit">왜 던킨인가?</h2>
<article class="infra">
    <div class="article-header">
        <h3 class="article-header-tit">INFRA</h3>
        <p class="article-header-desc">던킨의 <span>차별화 포인트</span>(Value Proposition), <span>‘도넛 그리고 커피’</span>이다.</p>
    </div>
    <div class="infra-wrap">
        <ul>
            <li class="infra-box clearfix">
                <div>
                    <h4 class="infra-box-tit">Donut</h4>
                    <p class="infra-box-desc"><span>안양 공장</span>을 중심으로 전국 7개의 도넛 전용 공장에서<br>매일 약40만 개의 신선한 도넛을 생산할 수 있는 아시아<br>최대의 도넛 생산 공장 시설이 있습니다.</p>
                </div>
                <figure class="infra-box-img"><img src="/img/infra-img01.png" alt=""></figure>
            </li>
            <li class="infra-box clearfix">
                <div>
                    <h4 class="infra-box-tit">Coffee</h4>
                    <p class="infra-box-desc"><span>음성 로스팅 센터</span>는 던킨 본사가 있는 미국<br>로스팅 센터 외 유일한  던킨 로스팅 센터로<br>국내 업계 최초의 커피 로스팅 공장을<br>운영하고 있습니다.</p>
                </div>
                <figure class="infra-box-img"><img src="/img/infra-img02.png" alt=""></figure>
            </li>
        </ul>
    </div>
</article>
<article class="marketing">
    <div class="article-header">
        <h3 class="article-header-tit">MAKETING</h3>
        <p class="article-header-desc">매출은 "객수*객단가"라는 평범한 명제에서 <span>'이기는 마케팅'</span>을 통한<span><br>새로운 고객 창출 및 제품 개발</span>을 하고 있습니다.</p>
    </div>
    <ul class="marketing-wrap">
        <li class="marketing-box clearfix">
            <div class="marketing-box-header">
                <h4 class="marketing-box-tit">Item?</h4>
                <p class="marketing-box-desc">던킨은 국내외 <span>유명 캐릭터 및 브랜드 이슈아이템</span>을 마케팅에 활용하고 있습니다. </p>
            </div>
            <figure class="marketing-box-img"><img src="/img/marketing-item-img01.png" alt=""></figure>
            <ul class="marketing-img-wrap">
                <li><figure><img src="/img/marketing-item-img02.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-item-img03.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-item-img04.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-item-img05.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-item-img06.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-item-img07.png" alt=""></figure></li>
            </ul>
        </li>
        <li class="marketing-box clearfix">
            <div class="marketing-box-header">
                <h4 class="marketing-box-tit">매월새로운 제품!</h4>
                <p class="marketing-box-desc">글로벌 던킨 R&D센터의 지원을 받아 개발하여 매월 <span>새로운 제품</span>을 출시하고 있습니다.</p>
            </div>
            <figure class="marketing-box-img"><img src="/img/marketing-new-img01.png" alt=""></figure>
            <ul class="marketing-img-wrap">
                <li><figure><img src="/img/marketing-new-img02.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-new-img03.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-new-img04.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-new-img05.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-new-img06.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-new-img07.png" alt=""></figure></li>
            </ul>
        </li>
        <li class="marketing-box clearfix">
            <div class="marketing-box-header">
                <h4 class="marketing-box-tit">모바일 쿠폰 채널</h4>
                <p class="marketing-box-desc">성장하는 시장인 <span>모바일과 딜리버리 시장</span>에서의 던킨의 존재감!</p>
            </div>
            <figure class="marketing-box-img"><img src="/img/marketing-m-img01.png" alt=""></figure>
            <ul class="marketing-img-wrap">
                <li><figure><img src="/img/marketing-m-img02.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-m-img03.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-m-img04.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-m-img05.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-m-img06.png" alt=""></figure></li>
                <li><figure><img src="/img/marketing-m-img07.png" alt=""></figure></li>
            </ul>
        </li>
    </ul>
</article>
<article class="easy">
    <div class="article-header">
        <h3 class="article-header-tit">EASY DUNKIN</h3>
        <p class="article-header-desc">역량있는 영업전문가들이 <span>점포운영을 쉽게</span> 도와드립니다.</p>
    </div>
    <div class="easy-wrap">
        <div class="easy-header">
            <h4 class="easy-tit"><span>[신규점 12주프로세스]</span>운영</h4>
            <p class="easy-desc">던킨을 시작하는 사장님들이 오픈 전 1개월, 오픈 후 2개월<br>총 12주간 사전 오픈 준비 및 오픈 이후 점포가 안정화 될 수 있도록<br>역량있는 영업전문가들이 책임져드립니다.</p>
        </div>
        <ul class="easy-box clearfix">
            <li>
                <em class="easy-box-num">01</em>
                <strong class="easy-box-tit">4주 전</strong>
                <p class="easy-box-txt">매장관리자(SV)<br>선정 및 오픈 준비</p>
            </li>
            <li>
                <em class="easy-box-num">02</em>
                <strong class="easy-box-tit">3주 전</strong>
                <p class="easy-box-txt">약 700점포 중<br>유사 점포 선정</p>
            </li>
            <li>
                <em class="easy-box-num">03</em>
                <strong class="easy-box-tit">2주 전</strong>
                <p class="easy-box-txt">유사 점포들의<br>데이터 추출</p>
            </li>
            <li>
                <em class="easy-box-num">04</em>
                <strong class="easy-box-tit">1주 전</strong>
                <p class="easy-box-txt">오픈준비 및 근무자 교육</p>
                <div class="easy-box-plus"><p>현장 교육 및 지원</p><span class="material-symbols-outlined">add</span></div>
            </li>
            <li>
                <em class="easy-box-num">05</em>
                <strong class="easy-box-tit">오픈</strong>
                <p class="easy-box-txt">그랜드오픈</p>
            </li>
            <li>
                <em class="easy-box-num">06</em>
                <strong class="easy-box-tit">2주차</strong>
                <p class="easy-box-txt">우리점포<br>판매데이터 축적</p>
            </li>
            <li>
                <em class="easy-box-num">07</em>
                <strong class="easy-box-tit">4주차</strong>
                <p class="easy-box-txt">스마트주문<br>시스템도입</p>
            </li>
            <li>
                <em class="easy-box-num">08</em>
                <strong class="easy-box-tit">6주차</strong>
                <p class="easy-box-txt">매출 분석 및<br>손익 리뷰</p>
            </li>
            <li>
                <em class="easy-box-num">09</em>
                <strong class="easy-box-tit">8주차</strong>
                <p class="easy-box-txt">현장 재건<br>활동 진행</p>
            </li>
        </ul>
    </div>
</article>


</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
