<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="keywords" content="던킨, 도넛, 도너츠, 커피, DUNKIN' DONUTS, dunkindonuts, 던킨도너츠" /> 
<meta name="description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!" />

<meta name="robots" content="index">
<meta property="og:title" content="[Sweet Break, DUNKIN’ DONUTS]" />
<meta property="og:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">
<meta property="og:type" content="website" />
<meta property="og:image" content="/img/og-img.jpg" />
<meta name="twitter:card" content="summary">
<meta name="twitter:title" content="[Sweet Break, DUNKIN’ DONUTS]">
<meta name="twitter:url" content="https://www.dunkindonuts.co.kr/"/>
<meta name="twitter:image" content="/img/og-img.jpg">
<meta name="twitter:description" content="던킨도너츠에서 다양한 제품과 행사를 만나보세요!">

<meta http-equiv="imagetoolbar" content="no">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<title>던킨</title>
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/css/default.css?ver=191110">
<link rel="stylesheet" href="http://ringpuppy2.dothome.co.kr/js/font-awesome/css/font-awesome.min.css?ver=191110">
<!--[if lte IE 8]>
<script src="http://ringpuppy2.dothome.co.kr/js/html5.js"></script>
<![endif]-->
<script>
// 자바스크립트에서 사용하는 전역변수 선언
var g5_url       = "http://ringpuppy2.dothome.co.kr";
var g5_bbs_url   = "http://ringpuppy2.dothome.co.kr/bbs";
var g5_is_member = "";
var g5_is_admin  = "";
var g5_is_mobile = "";
var g5_bo_table  = "";
var g5_sca       = "";
var g5_editor    = "";
var g5_cookie_domain = "";
</script>



<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />


<link rel="apple-touch-icon" sizes="57x57" href="/img/favicon/apple-icon-57x57.png">
<link rel="apple-touch-icon" sizes="60x60" href="/img/favicon/apple-icon-60x60.png">
<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon/apple-icon-72x72.png">
<link rel="apple-touch-icon" sizes="76x76" href="/img/favicon/apple-icon-76x76.png">
<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon/apple-icon-114x114.png">
<link rel="apple-touch-icon" sizes="120x120" href="/img/favicon/apple-icon-120x120.png">
<link rel="apple-touch-icon" sizes="144x144" href="/img/favicon/apple-icon-144x144.png">
<link rel="apple-touch-icon" sizes="152x152" href="/img/favicon/apple-icon-152x152.png">
<link rel="apple-touch-icon" sizes="180x180" href="/img/favicon/apple-icon-180x180.png">
<link rel="icon" type="image/png" sizes="192x192"  href="/img/favicon/android-icon-192x192.png">
<link rel="icon" type="image/png" sizes="32x32" href="/img/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="96x96" href="/img/favicon/favicon-96x96.png">
<link rel="icon" type="image/png" sizes="16x16" href="/img/favicon/favicon-16x16.png">
<link rel="manifest" href="/img/favicon/manifest.json">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="/img/favicon/ms-icon-144x144.png">
<meta name="theme-color" content="#ffffff">

<link rel="stylesheet" href="https://unpkg.com/swiper@8/swiper-bundle.min.css" />
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>


<script src="http://ringpuppy2.dothome.co.kr/js/jquery-1.12.4.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery-migrate-1.4.1.min.js"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/jquery.menu.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/common.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/wrest.js?ver=191110"></script>
<script src="http://ringpuppy2.dothome.co.kr/js/placeholders.min.js"></script>
</head>
<body>

<link rel="stylesheet" href="/css/sub-common.css">
<link rel="stylesheet" href="/css/sub-menu.css">
<script src="/js/sub.js"></script>

<!-- 상단 시작 { -->
<div class="skip-nav">
    <a href="#container">본문 바로가기</a>
</div>
<header id="header">
    <div class="inner"><!-- 1280 가운데정렬 -->
        <h1 class="logo"><a href="/">던킨</a></h1>
        <h2 class="hidden">메인메뉴</h2>
        <nav class="gnb">
            <ul class="gnb-wrap">
                <li class="depth1">
                    <a href="/sub/sub-brand.php">BRAND</a>
                    <dl class="gnb-s">
                        <dt>BRAND</dt>
                        <dd>던킨이야기</dd>
                        <dd><span>던킨도너츠</span>에<br>대해서 알아보세요.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-brand.php">브랜드 소개</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=brand">브랜드 소식</a></li>
                        <li><a href="/sub/sub-brand03.php">CF</a></li>
                        <li><a href="/sub/sub-brand04.php">왜 던킨인가?</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">STORE</a>
                    <dl class="gnb-s">
                        <dt>STORE</dt>
                        <dd>매장찾기</dd>
                        <dd>나와 가장 가까운<br><span>매장</span>을 찾아보세요.</dd>
                        <dd><img src="/img/gnb-img02.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=find">매장찾기</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=partner">신규매장</a></li>
                        <li><a href="/sub/sub-store03.php">품질우수가맹점</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">MENU</a>
                    <dl class="gnb-s">
                        <dt>MENU</dt>
                        <dd>이달의 도넛</dd>
                        <dd>매번 새로운<br>던킨의 다양한<br><span>도넛</span>을 만나보세요.</dd>
                        <dd><img src="/img/gnb-img03.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu&page=1">DONUT</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu02">SANDWICHES</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu03">COFFEE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_baverage">BEVERAGE</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=menu_others">OTHERS</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-guide.php">창업안내</a>
                    <dl class="gnb-s">
                        <dt>START</dt>
                        <dd>창업안내</dd>
                        <dd>여러분의<br><span>새로운 출발,</span>던킨이<br>도와드리겠습니다.</dd>
                        <dd><img src="/img/gnb-img01.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-guide.php">대한민국 가맹시장</a></li>
                        <li><a href="/sub/sub-guide02.php">SPC와 함께하는</a></li>
                        <li><a href="/sub/sub-guide03.php">가맹점 개설절차</a></li>
                        <li><a href="/sub/sub-guide04.php">사업설명회</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa">FAQ</a></li>
                    </ul>
                </li>
                <li class="depth1">
                    <a href="/sub/sub-center.php">고객센터</a>
                    <dl class="gnb-s">
                        <dt>CENTER</dt>
                        <dd>고객센터</dd>
                        <dd>던킨의 <span>고개센터를</span><br>통해 궁금증을 해결하세요.</dd>
                        <dd><img src="/img/gnb-img05.png" alt=""></dd>
                    </dl>
                    <ul class="depth2">
                        <li><a href="/sub/sub-center.php">접수 및 처리 절차</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=qa05">자주하는 질문</a></li>
                        <li><a href="#">보도자료</a></li>
                        <li><a href="http://ringpuppy2.dothome.co.kr/bbs/board.php?bo_table=gallery">이벤트</a></li>
                    </ul>
                </li>
            </ul>
            <div class="gnb-bg"></div>
        </nav>
        <div class="tnb">
            <ul class="tnb-login">        
                                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/register.php">JOIN</a></li>
                <li><a href="http://ringpuppy2.dothome.co.kr/bbs/login.php">LOGIN</a></li>
                            </ul>
        </div>
    </div>
</header>
<!-- } 상단 끝 -->


<!-- 콘텐츠 시작 { -->
<main id="container">
    <section class="sub06">
        <div class="inner">

<h2 class="tit">개인정보처리방침</h2>
<div class="personal">
    <article class="personal-top">
        <h3>던킨도너츠 개인정보처리방침 입니다</h3>
        <p>던킨도너츠 홈페이지(<span>www.dunkindonuts.co.kr</span>)는 (이하 '회사'는)<br>고객님의 개인정보를 중요시하며, “정보통신망 이용촉진 및 정보보호”에 관한 법률을 준수하고 있습니다.<br>던킨도너츠 홈페이지는 개인정보처리방침을 통하여 고객님께서 제공하시는 개인정보가 어떠한 용도와 방식으로 이용되고 있으며,<br>개인정보보흐를 위해 어떠한 조치가 취해지고 있는지 알려드립니다.</p>
        <p>회사 서비스의 개인정보처리방침은 다음과 같은 내용을 담고 있습니다.</p>
        <em>1. 수집하는 개인정보의 항목<br>2. 개인정보 수집 목적<br>3. 개인정보 수집 방법<br>4. 개인정보 보유 및 이용기간<br>5. 개인정보 파기절차 및 방법<br>6. 개인정보 자동수집 장치 설치/운영 및 거부에 관한 사항<br>7. 개인정보의 제3자 제공<br>8. 개인정보의 취급위탁<br>9. 회원 및 법정대리인의 권리와 그 행사 방법<br>10. 개인정보관리책임자 및 담당자의 연락처<br>11. 개인정보 열람 및 정정, 수집 및 이용에 대한 동의 철회<br>12. 개인정보의 기술적/관리적 보호 대책<br>13. 기타<br>14. 고지의 의무</em>
    </article>
    <article class="personal-contents">
        <h3>수집하는 개인정보의 항목</h3>
        <p>던킨도너츠 홈페이지는 다양한 서비스 제공을 위하여, 적법한 수단을 통하여 아래와 같은 회원 정보를 수집하고 있습니다.</p>
        <table>
            <thead>
                <tr>
                    <th scope="col" colspan="2">구분</th>
                    <th scope="col">수집항목</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td rowspan="3">필수항목</td>
                    <td>SPC ONEPASS 통합 회원가입</td>
                    <td>SPC ONEPASS통합 회원 ID</td>
                </tr>
                <tr>
                    <td>던킨도너츠 홈페이지</td>
                    <td>아이디, 암호화된 동일 식별번호(CI)</td>
                </tr>
                <tr>
                    <td>1:1 문의하기</td>
                    <td>이름, 전화번호, 이메일 주소</td>
                </tr>
                <tr>
                    <td colspan="2">이벤트 진행 시 수집되는 항목</td>
                    <td>아이디, 이름, 전화번호</td>
                </tr>
            </tbody>
        </table>
        <p class="personal-info">이용자의 인터넷 등 로그기록/이용자 접속지 추적자료 : 3개월(통신비밀보호법)</p>
    </article>
    <article class="personal-contents">
        <h3>개인정보 수집 목적</h3>
        <p>던킨도너츠 홈페이지에서는 던킨도너츠 서비스 이용에 관한 정보를 제공하고 고지하기 위하여 개인정보를 수집하고 있습니다.</p>
        <table>
            <thead>
                <tr>
                    <th>구분</th>
                    <th>이용목적</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>SPC ONEPASS 통합 회원가입</td>
                    <td>SPC ONEPASS 통합 회원서비스 가입 (던킨도너츠 운영 DB 미 저장)</td>
                </tr>
                <tr>
                    <td>던킨도너츠 홈페이지</td>
                    <td>던킨도너츠 서비스 제공</td>
                </tr>
                <tr>
                    <td>1:1 문의하기</td>
                    <td>SPC 고객센터 문의 처리 (던킨도너츠 운영 DB 미 저장)</td>
                </tr>
                <tr>
                    <td>이벤트 진행 시 수집되는 항목</td>
                    <td>이벤트 및 프로모션 참여 확인 및 경품 배송 등의 서비스 제공</td>
                </tr>
            </tbody>
        </table>
    </article>
    <article class="personal-contents">
        <h3>개인정보 수집 방법</h3>
        <p>던킨도너츠 홈페이지는 다음과 같은 방법으로 개인정보를 수집합니다.</p>
        <ul>
            <li>던킨도너츠 홈페이지에서 운영하는 이벤트 응모, 전화상담 이용</li>
            <li>홈페이지 이용 시 생성(홈페이지 접속 이력 및 쿠키)</li>
        </ul>
    </article>
    <article class="personal-contents">
        <h3>개인정보 보유 및 이용기간</h3>
        <p>던킨도너츠 홈페이지는 개인정보 수집 및 이용목적이 달성된 후에는 예외 없이 해당 정보를 지체 없이 파기합니다.<br>
            (단, 이용자의 별도 동의를 받거나 관련 법령에 따라 보관이 필요할 경우에는 예외적으로 이를 보유할 수 있습니다.)</p>
    </article>
    <article class="personal-contents">
        <h3>개인정보 파기절차 및 방법</h3>
        <p>던킨도너츠 홈페이지는 원칙적으로 개인정보 수집 및 이용목적이 달성된 후에는 해당 정보를 지체없이 파기합니다. 파기절차 및 방법은 다음과 같습니다.</p>
        <h4>파기절차</h4>
        <p>회원님이 서비스 이용 등을 위해 입력하신 정보는 목적이 달성된 후 별도의 DB로 옮겨져(종이의 경우 별도의 서류함) 내부 방침 및 기타 관련 법령에 의한 정보보호 사유에 따라(보유 및 이용기간 참조) 일정 기간 저장된 후 파기 합니다. 별도 DB로 옮겨진 개인정보는 법률에 의한 경우가 아니고서는 보유되어지는 이외의 다른 목적으로 이용되지 않습니다.</p>
        <h4>파기방법</h4>
        <ul>
            <li>전자적 파일형태로 저장된 개인정보는 기록을 재생할 수 없는 기술적 방법을 사용하여 삭제합니다.</li>
            <li>종이에 출력된 개인정보는 분쇄기로 분쇄하거나 소각을 통하여 파기합니다.</li>
        </ul>
    </article>
    <article class="personal-contents">
        <h3>개인정보 자동수집 장치 설치/운영 및 그 거부에 관한 사항</h3>
        <p>던킨도너츠 홈페이지는 귀하의 정보를 수시로 저장하고 찾아내는 ‘쿠키(cookie)’ 등을 운용합니다. 쿠키란 홈페이지를 운영하는데 이용되는 서버가 귀하의 브라우저에 보내는 아주 작은 텍스트 파일로서 귀하의 컴퓨터 하드디스크에 저장됩니다. 던킨도너츠 홈페이지는 다음과 같은 목적을 위해 쿠키를 사용합니다.</p>
        <h4>쿠키 등 사용 목적</h4>
        <p>회원과 비회원의 접속 빈도나 방문 시간 등을 분석, 이용자의 취향과 관심분야를 파악 및 자취 추적, 각종 이벤트 참여 정도 및 방문 회수 파악 등을 통한 타겟 마케팅 및 개인 맞춤 서비스 제공, 귀하는 쿠키 설치에 대한 선택권을 가지고 있습니다. 따라서, 귀하는 웹브라우저에서 옵션을 설정함으로써 모든 쿠키를 허용하거나, 쿠키가 저장될 때마다 확인을 거치거나, 아니면 모든 쿠키의 저장을 거부할 수도 있습니다.</p>
        <h4>쿠키 설정 거부 방법 예</h4>
        <p>쿠키 설정을 거부하는 방법으로는 회원님이 사용하시는 웹 브라우저의 옵션을 선택함으로써 모든 쿠키를 허용하거나 쿠키를 저장할 때마다 확인을 거치거나, 모든 쿠키의 저장을 거부할 수 있습니다.</p>
        <p>설정방법 예(인터넷 익스플로어의 경우) 웹 브라우저 상단의 도구 > 인터넷 옵션 > 개인정보 단, 귀하께서 쿠키 설치를 거부하였을 경우 서비스 제공에 어려움이 있을 수 있습니다.</p>
    </article>
</div>

</div>
</section>

</main>
<!-- } 메인콘텐츠 끝 -->


<!-- 하단 시작 { -->
<footer id="footer">
    <div class="inner">
        <h2 class="f-logo">던킨</h2>
        <ul class="f-menu clearfix">
            <li><a href="/sub/sub-f-use.php">이용약관</a></li>
            <li><a href="/sub/sub-f-personal.php">개인정보처리방침</a></li>
            <li><a href="/sub/sub-f-privacy.php">영상정보처리기기운영방침</a></li>
            <li><a href="/sub/sub-f-safety.php">안전보건경영방침</a></li>
        </ul>
        <div class="f-banner">
            <div class="f-site">
                <p class="f-site-tit">Family site<span class="material-symbols-outlined">expand_less</span></p>
                <ul class="f-site-box">
                    <li><a href="https://www.spc.co.kr/">SPC그룹</a></li>
                    <li><a href="http://www.brkorea.co.kr/">비알코리아</a></li>
                    <li><a href="http://www.baskinrobbins.co.kr/">배스킨라빈스</a></li>
                    <li><a href="https://www.paris.co.kr/">파리바게뜨</a></li>
                    <li><a href="https://shany.co.kr/">샤니</a></li>
                    <li><a href="https://www.caffe-pascucci.co.kr/index.asp">파스쿠찌</a></li>
                    <li><a href="http://www.happypointcard.com/page/main/index.spc;jsessionid=044D0806A9BA8A6F21BEDA177BB8A053">해피포인트카드</a></li>
                    <li><a href="https://dunkinschool.hunet.co.kr/Login/LoginGate">던킨 온라인 스쿨</a></li>
                    <li><a href="https://dunkin.alba.co.kr/job/brand/main.asp">던킨 아르바이트</a></li>
                </ul>
            </div>
            <ul class="f-sns">
                <li><a href="https://www.facebook.com/DunkinKorea" target="_blank">페이스북</a></li>
                <li><a href="https://www.instagram.com/dunkin_kr/" target="_blank">인스타그램</a></li>
                <li><a href="https://blog.naver.com/dunkin_kr" target="_blank">블로그</a></li>
                <li><a href="https://www.youtube.com/user/dunkindonutskorea" target="_blank">유튜브</a></li>
                <li><a href="https://twitter.com/dunkin_kr" target="_blank">트위터</a></li>
            </ul>
            <ul class="f-mark">
                <li><a href="http://www.spc.co.kr/contributionAll"  target="_blank">SPC행복한 이야기</a></li>
                <li><a href="https://www.kca.go.kr/ccm/" target="_blank">소비자중심경영</a></li>
                <li><a href="https://knqa.ksa.or.kr/knqa/2276/subview.do" target="_blank">국가품질상</a></li>
            </ul>
        </div>
        <div class="f-copy">
            <ul class="f-add clearfix">
                <li><address>서울특별시 서초구 남부순환로 2620(양재동 11-149번지)</address></li>
                <li>TEL : 080-555-3131</li>
                <li>VOC상담: 080-555-3131</li>
                <li>개인정보관리책임자 : 김경우</li>
                <li>사업자 등록번호 : 303-81-09535</li>
                <li>비알코리아(주) 대표이사 도세호</li>
            </ul>
            <p>COPYRIGHT Ⓒ 2016 BRKOREA COMPANY. ALL RIGHTS RESERVED.</p>
        </div>
    </div>
</footer>

<!-- Swiper JS -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<!-- Initialize Swiper -->
<script>
    var swiper = new Swiper(".mySwiper", {
    slidesPerView: 1,
    spaceBetween: 0,
    loop: true,
    pagination: {
        el: ".swiper-pagination",
        clickable: true,
    },
    navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
    },
    });
</script>


<!-- } 하단 끝 -->

<script>
$(function() {
    // 폰트 리사이즈 쿠키있으면 실행
    font_resize("container", get_cookie("ck_font_resize_rmv_class"), get_cookie("ck_font_resize_add_class"));
});
</script>



<!-- ie6,7에서 사이드뷰가 게시판 목록에서 아래 사이드뷰에 가려지는 현상 수정 -->
<!--[if lte IE 7]>
<script>
$(function() {
    var $sv_use = $(".sv_use");
    var count = $sv_use.length;

    $sv_use.each(function() {
        $(this).css("z-index", count);
        $(this).css("position", "relative");
        count = count - 1;
    });
});
</script>
<![endif]-->


</body>
</html>
